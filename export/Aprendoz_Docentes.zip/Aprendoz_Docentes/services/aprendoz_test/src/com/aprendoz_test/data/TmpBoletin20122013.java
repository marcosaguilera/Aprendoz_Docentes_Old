
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TmpBoletin20122013
 *  09/03/2014 16:11:01
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013() {
    }

    public TmpBoletin20122013(TmpBoletin20122013Id id) {
        this.id = id;
    }

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
