
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscripcionesVistaInscAlumnCurso
 *  09/03/2014 16:11:01
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCurso() {
    }

    public InscripcionesVistaInscAlumnCurso(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
