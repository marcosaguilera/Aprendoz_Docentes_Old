
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesAsistenciaAsistencias
 *  09/03/2014 16:11:01
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistencias() {
    }

    public DocentesAsistenciaAsistencias(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
