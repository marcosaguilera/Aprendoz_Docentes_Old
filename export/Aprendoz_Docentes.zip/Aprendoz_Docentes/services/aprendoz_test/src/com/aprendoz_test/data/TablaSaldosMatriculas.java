
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaSaldosMatriculas
 *  09/03/2014 16:11:01
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculas() {
    }

    public TablaSaldosMatriculas(TablaSaldosMatriculasId id) {
        this.id = id;
    }

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
