
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  09/03/2014 16:11:01
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogrados() {
    }

    public AprLogrados(AprLogradosId id) {
        this.id = id;
    }

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
