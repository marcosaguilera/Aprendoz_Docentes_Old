
package com.aprendoz_test.data;



/**
 *  aprendoz_test.BisUsers
 *  09/03/2014 16:11:01
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsers() {
    }

    public BisUsers(BisUsersId id) {
        this.id = id;
    }

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
