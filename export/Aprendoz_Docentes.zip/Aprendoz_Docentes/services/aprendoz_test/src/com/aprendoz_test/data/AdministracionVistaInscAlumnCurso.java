
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumnCurso
 *  09/03/2014 16:11:01
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCurso() {
    }

    public AdministracionVistaInscAlumnCurso(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
