
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaPersonasDemografica
 *  09/03/2014 16:11:01
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemografica() {
    }

    public DocentesVistaPersonasDemografica(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
