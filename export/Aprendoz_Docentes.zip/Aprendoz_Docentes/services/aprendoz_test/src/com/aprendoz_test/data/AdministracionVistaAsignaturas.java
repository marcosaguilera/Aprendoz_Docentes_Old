
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturas
 *  09/03/2014 16:11:01
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturas() {
    }

    public AdministracionVistaAsignaturas(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
