
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TmpEnrLog
 *  09/03/2014 16:11:01
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLog() {
    }

    public TmpEnrLog(TmpEnrLogId id) {
        this.id = id;
    }

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
