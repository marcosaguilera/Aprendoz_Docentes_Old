
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  09/03/2014 16:11:02
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopy() {
    }

    public CalifEstCopy(CalifEstCopyId id) {
        this.id = id;
    }

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
