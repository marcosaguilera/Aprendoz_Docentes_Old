
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCurso
 *  09/03/2014 16:11:01
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCurso() {
    }

    public InscAlumAsigCurso(InscAlumAsigCursoId id) {
        this.id = id;
    }

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
