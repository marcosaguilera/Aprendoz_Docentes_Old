
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscipcionesVistaAsignaturas
 *  09/03/2014 16:11:02
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturas() {
    }

    public InscipcionesVistaAsignaturas(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
