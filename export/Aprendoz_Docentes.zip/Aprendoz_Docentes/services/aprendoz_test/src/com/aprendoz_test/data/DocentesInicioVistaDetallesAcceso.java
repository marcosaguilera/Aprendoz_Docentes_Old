
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInicioVistaDetallesAcceso
 *  09/03/2014 16:11:01
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAcceso() {
    }

    public DocentesInicioVistaDetallesAcceso(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
