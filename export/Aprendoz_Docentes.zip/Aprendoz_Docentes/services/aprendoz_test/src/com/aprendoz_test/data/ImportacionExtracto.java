
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ImportacionExtracto
 *  09/03/2014 16:11:01
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtracto() {
    }

    public ImportacionExtracto(ImportacionExtractoId id) {
        this.id = id;
    }

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
