
package com.aprendoz_test.data;



/**
 *  aprendoz_test.FacturacionSapiens
 *  09/03/2014 16:11:02
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiens() {
    }

    public FacturacionSapiens(FacturacionSapiensId id) {
        this.id = id;
    }

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
