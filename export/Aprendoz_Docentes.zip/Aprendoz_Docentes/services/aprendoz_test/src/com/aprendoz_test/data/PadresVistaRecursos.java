
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  09/03/2014 16:11:01
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursos() {
    }

    public PadresVistaRecursos(PadresVistaRecursosId id) {
        this.id = id;
    }

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
