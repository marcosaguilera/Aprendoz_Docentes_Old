
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CodigosCorrecion
 *  09/12/2013 08:43:16
 * 
 */
public class CodigosCorrecion {

    private String codigo;

    public CodigosCorrecion() {
    }

    public CodigosCorrecion(String codigo) {
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}
