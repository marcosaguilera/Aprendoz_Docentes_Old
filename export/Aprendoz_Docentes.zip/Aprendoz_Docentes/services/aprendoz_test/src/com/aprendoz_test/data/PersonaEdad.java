
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PersonaEdad
 *  09/03/2014 16:11:01
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdad() {
    }

    public PersonaEdad(PersonaEdadId id) {
        this.id = id;
    }

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
