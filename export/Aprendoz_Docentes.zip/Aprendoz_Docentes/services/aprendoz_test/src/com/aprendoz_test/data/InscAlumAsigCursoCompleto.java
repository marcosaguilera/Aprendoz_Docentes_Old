
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCursoCompleto
 *  09/03/2014 16:11:02
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompleto() {
    }

    public InscAlumAsigCursoCompleto(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
