
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anuncio
 *  09/03/2014 16:11:01
 * 
 */
public class Anuncio {

    private String anuncio;

    public Anuncio() {
    }

    public Anuncio(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
