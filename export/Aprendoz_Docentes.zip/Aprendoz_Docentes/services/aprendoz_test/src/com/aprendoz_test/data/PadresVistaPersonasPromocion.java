
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonasPromocion
 *  09/03/2014 16:11:01
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocion() {
    }

    public PadresVistaPersonasPromocion(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
