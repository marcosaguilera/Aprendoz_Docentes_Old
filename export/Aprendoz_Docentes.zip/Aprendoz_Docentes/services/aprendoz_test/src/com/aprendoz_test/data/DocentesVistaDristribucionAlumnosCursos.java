
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaDristribucionAlumnosCursos
 *  09/03/2014 16:11:01
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursos() {
    }

    public DocentesVistaDristribucionAlumnosCursos(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
