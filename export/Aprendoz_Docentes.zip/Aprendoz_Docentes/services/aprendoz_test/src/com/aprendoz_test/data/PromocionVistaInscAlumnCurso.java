
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PromocionVistaInscAlumnCurso
 *  09/03/2014 16:11:01
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCurso() {
    }

    public PromocionVistaInscAlumnCurso(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
