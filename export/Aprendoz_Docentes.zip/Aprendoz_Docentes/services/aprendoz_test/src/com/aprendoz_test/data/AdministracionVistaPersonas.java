
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaPersonas
 *  09/03/2014 16:11:01
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonas() {
    }

    public AdministracionVistaPersonas(AdministracionVistaPersonasId id) {
        this.id = id;
    }

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
