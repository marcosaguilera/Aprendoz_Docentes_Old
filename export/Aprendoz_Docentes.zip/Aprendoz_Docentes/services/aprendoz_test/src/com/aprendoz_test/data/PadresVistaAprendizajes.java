
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaAprendizajes
 *  09/03/2014 16:11:01
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajes() {
    }

    public PadresVistaAprendizajes(PadresVistaAprendizajesId id) {
        this.id = id;
    }

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
