
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ServiciosListadoServiciosAlumnos
 *  09/03/2014 16:11:01
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnos() {
    }

    public ServiciosListadoServiciosAlumnos(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
