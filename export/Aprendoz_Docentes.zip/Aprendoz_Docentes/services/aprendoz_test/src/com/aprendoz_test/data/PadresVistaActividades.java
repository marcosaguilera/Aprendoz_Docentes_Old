
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  09/03/2014 16:11:01
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividades() {
    }

    public PadresVistaActividades(PadresVistaActividadesId id) {
        this.id = id;
    }

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
