
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturasCurso
 *  09/03/2014 16:11:01
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCurso() {
    }

    public AdministracionVistaAsignaturasCurso(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
