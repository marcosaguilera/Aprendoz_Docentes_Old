
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CurriculoGrado
 *  09/03/2014 16:11:02
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGrado() {
    }

    public CurriculoGrado(CurriculoGradoId id) {
        this.id = id;
    }

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
