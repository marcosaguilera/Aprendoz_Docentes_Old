
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DirectoresDocentesListadoReportes
 *  09/03/2014 16:11:01
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportes() {
    }

    public DirectoresDocentesListadoReportes(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
