
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaCalifFinal
 *  09/03/2014 16:11:01
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinal() {
    }

    public PadresVistaCalifFinal(PadresVistaCalifFinalId id) {
        this.id = id;
    }

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
