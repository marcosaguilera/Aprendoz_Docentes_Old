
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaAnticiposMatriculas
 *  09/03/2014 16:11:01
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculas() {
    }

    public TablaAnticiposMatriculas(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
